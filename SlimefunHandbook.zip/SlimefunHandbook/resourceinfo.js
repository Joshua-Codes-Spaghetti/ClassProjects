"use strict"

// Earlier: This is beyond atrocious for organizing code, HOWEVER, this should make it easier for functions to call the data
// I've only done the names... I'm going to hate this. (Referring to like 12 massive arrays of names, descriptions, notes, and all the dust types)

// Later: Alright, I'm giving up, I'll just have to make around 70 arrays*, but it's probably better this way *I meant objects

// Even later: BEHOLD, MY MAGNUM OPUS. (even if the rest of the website is lacklustre, THIS is some proper coding)

function openCalc() {
    // Switches from the item details sidebar to the calculator
    document.getElementById("page_details").innerHTML = `<img src='images/slimefun/gui/back.png' onclick='closeCalc()'>
    <form>
        <fieldset>
            <legend>Total Cost Calculator</legend>
            <label for='resName'>Resource Name:</label><br>
            <input type='text' list='resources' id='resName' placeholder='Enter a resource name'><br><br>
            <datalist id='resources'>
                <option value='Reinforced Alloy'>
                <option value='Hardened Metal'>
                <option value='Damascus Steel'>
                <option value='Steel'>
                <option value='Bronze'>
                <option value='Duralumin'>
                <option value='Billon'>
                <option value='Brass'>
                <option value='Aluminum Brass'>
                <option value='Aluminum Bronze'>
                <option value='Corinthian Bronze'>
                <option value='Solder'>
                <option value='Synthetic Sapphire'>
                <option value='Synthetic Diamond'>
                <option value='Raw Carbonado'>
                <option value='Nickel'>
                <option value='Cobalt'>
                <option value='Carbonado'>
                <option value='Ferrosilicon'>
                <option value='Sulfate'>
                <option value='Carbon'>
                <option value='Compressed Carbon'>
                <option value='Carbon Chunk'>
                <option value='24-Karat Gold'>
                <option value='22-Karat Gold'>
                <option value='20-Karat Gold'>
                <option value='18-Karat Gold'>
                <option value='16-Karat Gold'>
                <option value='14-Karat Gold'>
                <option value='12-Karat Gold'>
                <option value='10-Karat Gold'>
                <option value='8-Karat Gold'>
                <option value='6-Karat Gold'>
                <option value='4-Karat Gold'>
                <option value='Silicon'>
                <option value='Gilded Iron'>
                <option value='Synthetic Emerald'>
                <option value='Uranium'>
                <option value='Redstone Alloy'>
                <option value='Magnesium Salt'>
                <option value='Oil'>
                <option value='Fuel'>
                <option value='Nether Ice'>
                <option value='Blistering Ingot (33%)'>
                <option value='Blistering Ingot (66%)'>
                <option value='Blistering Ingot (100%)'>
                <option value='Enriched Nether Ice'>
                <option value='Neptunium'>
                <option value='Plutonium'>
                <option value='Boosted Uranium'>
            </datalist>
            <label for='mult'>How many are you making?:</label><br>
            <input type='text' id='mult' name='multiplier' placeholder='1'><br><br>
            <input type='button' value='Calculate' onclick='userCalc()'>
        </fieldset>
    </form>
    <div id="calcResult"></div>
    `;
}

function closeCalc() {
    // Switches back to the item details sidebar
    document.getElementById("page_details").innerHTML = `<article>
                <img src='images/slimefun/gui/forward.png' onclick='openCalc()'>
                <h1 id='itemName'>Item Name</h1>
                <p id='itemDesc'>
                    The description of an item, and the materials used to craft it.<br><br>
                    Includes the crafting recipe, base material costs can be found on the Calculators page
                </p>
            </article>
            <aside>
                <p id='itemNotes'>
                    This aside is where miscellaneous tips or info about the item will appear
                </p>
            </aside>`;
}
function userCalc() {
    let mat = document.getElementById("resName").value;
    let mult = document.getElementById("mult").value;
    if (mult < 1) {
        mult = 1;
    }
    //There's probably a more compact way of doing this, but it's not TOO bad.
    switch(mat) {
        case "Reinforced Alloy":
            reinforcedAlloy.getCost(mult);
            break;
        case "Hardened Metal":
            hardenedMetal.getCost(mult);
            break;
        case "Damascus Steel":
            damascusSteel.getCost(mult);
            break;
        case "Steel":
            steel.getCost(mult);
            break;
        case "Bronze":
            bronze.getCost(mult);
            break;
        case "Duralumin":
            duralumin.getCost(mult);
            break;
        case "Billon":
            billon.getCost(mult);
            break;
        case "Brass":
            brass.getCost(mult);
            break;
        case "Aluminum Brass":
            aluminumBrass.getCost(mult);
            break;
        case "Aluminum Bronze":
            aluminumBronze.getCost(mult);
            break;
        case "Corinthian Bronze":
            corinthianBronze.getCost(mult);
            break;
        case "Solder":
            solder.getCost(mult);
            break;
        case "Synthetic Sapphire":
            syntheticSapphire.getCost(mult);
            break;
        case "Synthetic Diamond":
            syntheticDiamond.getCost(mult);
            break;
        case "Raw Carbonado":
            rawCarbonado.getCost(mult);
            break;
        case "Nickel":
            nickel.getCost(mult);
            break;
        case "Cobalt":
            cobalt.getCost(mult);
            break;
        case "Carbonado":
            carbonado.getCost(mult);
            break;
        case "Ferrosilicon":
            ferrosilicon.getCost(mult);
            break;
        case "Sulfate":
            sulfate.getCost(mult);
            break;
        case "Carbon":
            carbon.getCost(mult);
            break;
        case "Compressed Carbon":
            compressedCarbon.getCost(mult);
            break;
        case "Carbon Chunk":
            carbonChunk.getCost(mult);
            break;
        case "24-Karat Gold":
            gold24.getCost(mult);
            break;
        case "22-Karat Gold":
            gold22.getCost(mult);
            break;
        case "20-Karat Gold":
            gold20.getCost(mult);
            break;
        case "18-Karat Gold":
            gold18.getCost(mult);
            break;
        case "16-Karat Gold":
            gold16.getCost(mult);
            break;
        case "14-Karat Gold":
            gold14.getCost(mult);
            break;
        case "12-Karat Gold":
            gold12.getCost(mult);
            break;
        case "10-Karat Gold":
            gold10.getCost(mult);
            break;
        case "8-Karat Gold":
            gold8.getCost(mult);
            break;
        case "6-Karat Gold":
            gold6.getCost(mult);
            break;
        case "4-Karat Gold":
            gold4.getCost(mult);
            break;
        case "Silicon":
            silicon.getCost(mult);
            break;
        case "Gilded Iron":
            gildedIron.getCost(mult);
            break;
        case "Synthetic Emerald":
            syntheticEmerald.getCost(mult);
            break;
        case "Uranium":
            uranium.getCost(mult);
            break;
        case "Redstone Alloy":
            redstoneAlloy.getCost(mult);
            break;
        case "Magnesium Salt":
            magnesiumSalt.getCost(mult);
            break;
        case "Oil":
            oil.getCost(mult);
            break;
        case "Fuel":
            fuel.getCost(mult);
            break;
        case "Nether Ice":
            netherIce.getCost(mult);
            break;
        case "Blistering Ingot (33%)":
            blisteringIngot33.getCost(mult);
            break;
        case "Blistering Ingot (66%)":
            blisteringIngot66.getCost(mult);
            break;
        case "Blistering Ingot (100%)":
            blisteringIngot100.getCost(mult);
            break;
        case "Enriched Nether Ice":
            enrichedNetherIce.getCost(mult);
            break;
        case "Neptunium":
            neptunium.getCost(mult);
            break;
        case "Plutonium":
            plutonium.getCost(mult);
            break;
        case "Boosted Uranium":  
            boostedUranium.getCost(mult);
            break;
        default:
            document.getElementById("calcResult").innerHTML="Error: Incorrect Resource Name";
            break;
    }
}

class resource {
    constructor(name, desc, notes, cost) {
        this.name = name; // Item Name
        this.desc = desc; // Information about the item and crafting instructions
        this.notes = notes; // Thoughts and tips
        this.cost = cost; // This is SO MUCH BETTER than having a bunch of different variables for each dust, at least when you have to work with other items too
    }
    getInfo() {
        // Function to set the sidebar info to the info of the resource, uses name, description, and notes
        closeCalc();
        document.getElementById("itemName").innerHTML = this.name;
        document.getElementById("itemDesc").innerHTML = this.desc;
        document.getElementById("itemNotes").innerHTML = this.notes;
    }
    getCost(multiplier = 1) {
        // Function to get a string of the total cost in dust
        // You must always ask, is this too much voodoo for our purposes? Is this too insane of code? Do we need to simplify for the weak, modern mind?
        // Split other costs string into items, then items string into costs and names, use .length for loop for flexibility

        let totalCostString = "<h3>Total Cost:</h3>"
        const splitCosts = this.cost.split("&");

        totalCostString += "<p>";

        for (let i = 0; i < splitCosts.length; i++) {
            const itemData = splitCosts[i].split("*");

            totalCostString += "" + (itemData[0]*multiplier) + " " + itemData[1] + "<br><br>";
        }
        totalCostString += "</p>";

        document.getElementById("calcResult").innerHTML = totalCostString;
    }
}

const reinforcedAlloy = new resource("Reinforced Alloy","An alloy as tough as it is complex, used widely for high-level equipment and machines.<br><br>Made with Damascus Steel, Hardened Metal, Corinthian Bronze, Solder, Billon, and 24-Karat Gold","If it's your first time making this, you're probably making hardened glass.<br>A royal pain to make every time you need it, have fun!",
    "8*Iron Dust&12*Gold Dust&7*Copper Dust&3*Tin Dust&2*Lead Dust&4*Aluminum Dust&8*Carbon");

const hardenedMetal = new resource("Hardened Metal","A hard alloy used in tools and machines.<br><br>Made with Damascus Steel, Duralumin, Aluminum Bronze, and Compressed Carbon","I like this one for no reason in particular, at least it isn't as complex as reinforced.",
    "4*Iron Dust&3*Copper Dust&1*Tin Dust&4*Aluminum Dust&6*Carbon")

const damascusSteel = new resource("Damascus Steel","Steel strengthened by folding and reforging, used in mid-level equipment and machines.<br><br>Made with Steel, Carbon, an Iron Ingot, and Iron Dust","The sequel to steel, you might accidentally make this without an output chest.",
    "4*Iron Dust&2*Carbon")

const steel = new resource("Steel","An alloy of iron and carbon, more flexible and durable than iron, used in many machines and some technical components.<br><br>Made with Carbon, Iron Dust, and an Iron Ingot","Machines use a lot, but it's rather cheap and I don't mind making it.",
    "2*Iron Dust&1*Carbon")

const bronze = new resource("Bronze","An alloy of copper and tin, used in some machines and components.<br><br>Made with a Copper Ingot, Copper Dust, and Tin Dust","Basically only used in alloys, feels like it uses more copper than I'd think.",
    "2*Copper Dust&1*Tin Dust")

const duralumin = new resource("Duralumin","An alloy of Aluminum and Copper with increased durability, used in machines and components.<br><br>Made with an Aluminum Ingot, Aluminum Dust, and Copper Dust","You're gonna need so much aluminum, figure out automated dust production. Other than that, I like this stuff.",
    "1*Copper Dust&2*Aluminum Dust");

const billon = new resource("Billon","An alloy of Silver and Copper, used in other alloys and some machines.<br><br>Made with a Silver Bar, Silver Dust, and Copper Dust","Rarely used, often forgotten.",
    "1*Copper Dust&2*Silver Dust");

const brass = new resource("Brass","An alloy of Copper and Zinc, used for some alloys and machines.<br><br>Made with a Copper Ingot, Copper dust, and Zinc Dust.","Like Billon, rarely used.",
    "2*Copper Dust&1*Zinc Dust");

const aluminumBrass = new resource("Aluminum Brass","Brass mixed with aluminum, used in technical components and machines.<br><br>Made with an Aluminum Ingot, Brass Ingot, and Aluminum Dust","Almost nothing uses this, I can't remember the last time I've needed more than a handful for anything.",
    "2*Copper Dust&2*Aluminum Dust&1*Zinc Dust");

const aluminumBronze = new resource("Aluminum Bronze","A mix of aluminum and bronze, used in alloys, components, and machines.<br><br>Made with an Aluminum Ingot, Bronze Ingot, and Aluminum Dust","Probably the first complex alloy you'll make, and I don't mind it.",
    "2*Copper Dust&1*Tin Dust&2*Aluminum Dust");

const corinthianBronze = new resource("Corinthian Bronze","Bronze mixed with all sorts of shiny metals, used in alloys, components, and machines.<br><br>Made with a Bronze Ingot, Copper Dust, Silver Dust, and Gold Dust","Shiny bronze, used mostly in machines.",
    "1*Gold Dust&3*Copper Dust&1*Tin Dust&1*Silver Dust");

const solder = new resource("Solder","An alloy of Lead and Tin used to make connections on electronics, and is used in the creation of some alloys.<br><br>Made with a Lead Ingot, Lead Dust, and Tin Dust","Boring and weird alloy. Yeah, I don't have much to say about this one.",
    "1*Tin Dust&2*Lead Dust");

const syntheticSapphire = new resource("Synthetic Sapphire","An artificial gem made by mixing Lapis Lazuli and Aluminum with Glass, used in technical components.<br><br>Made with a Lapis Lazuli, an Aluminum Ingot, Aluminum Dust, a Glass Block, and a Glass Pane","A pretty gem that doesn't have many uses",
    "2*Aluminum Dust&1*Glass&1*Glass Pane&1*Lapis Lazuli");

const syntheticDiamond = new resource("Synthetic Diamond","An artificial diamond that can be used like the real thing.<br><br>Made by processing a Carbon Chunk in a Pressure Chamber","Some servers might allow you to grind diamonds for carbon, which means you can have a diamond made of diamonds. A massive waste of diamonds if you aren't using it for Slimefun.",
    "32*Carbon&1*Flint");

const rawCarbonado = new resource("Raw Carbonado","An artificial gem made of carbon, but still requires extreme pressure to show its true potential.<br><br>Made with a Carbon Chunk, Synthetic Diamond, and Glass Pane","My heart weeps for the coal used to craft this.",
    "64*Carbon&2*Flint&1*Glass Pane");

const nickel = new resource("Nickel","A conductive alloy of Iron and Copper, used for many electronics.<br><br>Made with an Iron Ingot, Iron Dust, and Copper Dust","Water, fire, air and dirt,",
    "2*Iron Dust&1*Copper Dust"); // Music reference, you gotta know this.

const cobalt = new resource("Cobalt","A conductive alloy that compliments nickel, allowing for magnetism.<br><br>Made with a Nickel Ingot, Iron Dust, and Copper Dust","____ing Magnets, how do they work?",
    "3*Iron Dust&2*Copper Dust"); // If you're wondering why I'm including minor swearing in here, look above

const carbonado = new resource("Carbonado","A jet black artificial gem, used in high-level machinery and equipment.<br><br>Made by processing Raw Carbonado in a Pressure Chamber","This takes eight stacks of coal. No matter how pretty the texture is I will always hate this.",
    "64*Carbon&2*Flint&1*Glass Pane");

const ferrosilicon = new resource("Ferrosilicon","A conductive alloy of Iron and Silicon, used in machinery and other alloys.<br><br>Made with an Iron Ingot, Iron Dust, and Silicon","Technical components love this, but I'm pretty neutral.",
    "2*Iron Dust&1*Block of Quartz");

const dusts = new resource("Metal Dusts","Found through the sifting of gravel, and the washing of the resulting ore. Can be smelted down into bars of their respective material or used in more complex alloys.","Iron, Copper, and Gold dust can be obtained by grinding the respective ore in an ore grinder, copper is no longer the bottleneck!",
    "1*Sifted Ore");

const basicIngots = new resource("Basic Ingots","Made by smelting their respective dusts in a smeltry, used in alloys and a few technical components.","You'll usually need more dust than the ingots you make from them.",
    "1*Metal Dust");

const sulfate = new resource("Sulfate","A salt of sulfuric acid, and found in netherrack in small quanities.<br><br>Made with 16 Netherrack in an Ore Grinder","It's batteries again, isn't it?",
    "16*Netherrack");

const carbon = new resource("Carbon","Raw carbon, obtained from the compression of coal, used in many components and alloys.<br><br>Made with 8 Coal in a Compressor","You'll need lots of coal, consider farming spruce trees, making them into charcoal, and compressing that charcoal into coal.",
    "8*Coal");

const compressedCarbon = new resource("Compressed Carbon","A compressed version of carbon, used for hardened metal and some other components.<br>Made with 4 Carbon in a Compressor","Not terrible to make, but an ill omen for how much coal you'll need.",
    "4*Carbon");

const carbonChunk = new resource("Carbon Chunk","A large chunk of compressed carbon, used in the creation of Carbonado.<br><br>Created by surrounding a Flint with Compressed Carbon in an Enhanced Crafting Table","This is four stacks of coal. You will need another four stacks for Carbonado. Good luck.",
    "32*Carbon&1*Flint");

const gold24 = new resource("24-Karat Gold","Gold refined to the highest purity possible, used in high-level machines and other alloys.","Rule of thumb, Karats/2, then -1 is how much gold dust you need.",
    "11*Gold Dust");

const gold22 = new resource("22-Karat Gold","Gold refined through melting away impurities.<br><br>Increase its purity by smelting it with more gold dust","Rule of thumb, Karats/2, then -1 is how much gold dust you need.",
    "10*Gold Dust");

const gold20 = new resource("20-Karat Gold","Gold refined through melting away impurities.<br><br>Increase its purity by smelting it with more gold dust","Rule of thumb, Karats/2, then -1 is how much gold dust you need.",
    "9*Gold Dust");

const gold18 = new resource("18-Karat Gold","Gold refined through melting away impurities.<br><br>Increase its purity by smelting it with more gold dust","Rule of thumb, Karats/2, then -1 is how much gold dust you need.",
    "8*Gold Dust");

const gold16 = new resource("16-Karat Gold","Gold refined through melting away impurities.<br><br>Increase its purity by smelting it with more gold dust","Rule of thumb, Karats/2, then -1 is how much gold dust you need.",
    "7*Gold Dust");

const gold14 = new resource("14-Karat Gold","Gold refined through melting away impurities.<br><br>Increase its purity by smelting it with more gold dust","Rule of thumb, Karats/2, then -1 is how much gold dust you need.",
    "6*Gold Dust");

const gold12 = new resource("12-Karat Gold","Gold refined through melting away impurities.<br><br>Increase its purity by smelting it with more gold dust","Rule of thumb, Karats/2, then -1 is how much gold dust you need.",
    "5*Gold Dust");

const gold10 = new resource("10-Karat Gold","Gold refined through melting away impurities.<br><br>Increase its purity by smelting it with more gold dust","Rule of thumb, Karats/2, then -1 is how much gold dust you need.",
    "4*Gold Dust");

const gold8 = new resource("8-Karat Gold","Gold refined through melting away impurities.<br><br>Increase its purity by smelting it with more gold dust","Rule of thumb, Karats/2, then -1 is how much gold dust you need.",
    "3*Gold Dust");

const gold6 = new resource("6-Karat Gold","Gold refined through melting away impurities.<br><br>Increase its purity by smelting it with more gold dust","Rule of thumb, Karats/2, then -1 is how much gold dust you need.",
    "2*Gold Dust");

const gold4 = new resource("4-Karat Gold","Gold refined through melting away impurities.<br><br>Increase its purity by smelting it with more gold dust","Rule of thumb, Karats/2, then -1 is how much gold dust you need.",
    "1*Gold Dust");

const silicon = new resource("Silicon","An element obtained by smelting nether quartz, used in machinery and some alloys.<br><br>Made by smelting a Block of Quartz","Solar panels use crazy amounts, you'll also probably have a lot of quartz laying around if you mined it for experience.",
    "1*Block of Quartz");

const gildedIron = new resource("Gilded Iron","Gold turned into an alloy with iron, has uses in equipment and machinery.<br><br>Made with 24-Karat Gold and Iron Dust","Only used in a few tools and machines, a weird alloy.",
    "1*Iron Dust&11*Gold Dust");

const syntheticEmerald = new resource("Synthetic Emerald","An artifical gem that villagers find valuable, also used in some technical components.<br><br>Made with a Synthetic Sapphire, Aluminum Ingot, Aluminum Dust, Glass Block, and Glass Pane","Not too many uses, but really strains the aluminum stock.",
    "4*Aluminum Dust&2*Glass Block&2*Glass Pane&1*Lapis Lazuli");

const uranium = new resource("Uranium","Very radioactive, incredibly energy-dense, used to fuel nuclear reactors.<br><br>Made by combining four small chunks of uranium in an enhanced crafting table, which are made with nine tiny piles of uranium","The forbidden tennis ball, give it to someone without a hazmat suit and laugh.",
    "36*Tiny Piles of Uranium");

const redstoneAlloy = new resource("Redstone Alloy","An energetic alloy often used in machines to store and conduct power.<br><br>Made with a Hardened Metal, Ferrosilicon, Redstone Block, and Redstone Dust","So expensive, so commonly used, you might as well craft extra so you don't need to later.",
    "6*Iron Dust&2*Copper Dust&1*Tin Dust&4*Aluminum Dust&6*Carbon&1*Silicon&10*Redstone");

const magnesiumSalt = new resource("Magnesium Salt","Fuel source for magnesium generators.<br><br>Made by combining Magnesium Dust and Salt in a Heated Pressure Chamber","Salty magnesium, unless you've got addons, this is all magnesium does.",
    "1*Magnesium Dust&1*Salt");

const oil = new resource("Bucket of Oil","A fuel source for combustion reactor, also used in the creation of plasic, which is important to androids and some machines.<br><br>Obtained by Geo-mining","Don't let the US hear.",
    "1*x Geo-miner uses");

const fuel = new resource("Bucket of Fuel","Refined Oil, combustion reactors love this.<br><br>Made by processing a Bucket of Oil in a Refinery","Literally three times better than oil, it's amazing.",
    "1*Bucket of Oil");

const netherIce = new resource("Nether Ice","Moderately radioactive material mined from the nether, Hazmat suit recommended.<br><br>Obtained through Geo-mining in the nether","You get lots of this, and I've never used the thing it's used for. Don't worry about it.",
    "1*x Geo-miner uses");

const blisteringIngot33 = new resource("Blistering Ingot (33%)","An incomplete, highly radioactive combination of exotic materials, still requires a carbonado and nether star.<br><br>Made with 24-Karat Gold and Uranium","This part isn't too expensive, but it's useless unless you complete it.",
    "11*Gold Dust&36*Tiny Piles of Uranium");

const blisteringIngot66 = new resource("Blistering Ingot (66%)","An incomplete, highly radioactive combination of exotic materials, still requires a nether star.<br><br>Made by adding a Carbonado to the 33% Blistering Ingot","And there's the step that kills me. Too much coal.",
    "11*Gold Dust&64*Carbon&36*Tiny Piles of Uranium");

const blisteringIngot100 = new resource("Blistering Ingot","A horrifyingly radioactive alloy, with properties required for the highest-level machines.<br><br>Made by adding a nether star to the 66% Blistering Ingot","SPICY GOLD, I'd hate this so much less if it didn't take eight stacks of coal.",
    "11*Gold Dust&64*Carbon&36*Tiny Piles of Uranium&1*Nether Star");

const enrichedNetherIce = new resource("Enriched Nether Ice","Hazmat Suit is mandatory, used to create coolant cells for nether reactors.<br><br>Made by combining Plutonium and Nether Ice in a Heated Pressure Chamber","Hot ice? I don't get it either. I guess it's hot in two ways, given the radiation.",
    "1*Nether Ice&36*Tiny Piles of Uranium");

const neptunium = new resource("Neptunium","Semi-spent nuclear fuel, highly radioactive, and can be ran through a second time.<br><br>Made by reacting uranium in a Nuclear Reactor","Reduce, Reuse, Recycle, throw at someone and watch them cook!",
    "36*Tiny Piles of Uranium");

const plutonium = new resource("Plutonium","Fully spent nuclear fuel, still highly radioactive, and still has some uses.<br><br>Byproduct of reacting Neptunium in a Nuclear Reactor","A bit inconvenient to get, used by some addons, and I've never really made boosted uranium.",
    "36*Tiny Piles of Uranium");
    
const boostedUranium = new resource("Boosted Uranium","The most energy-dense fuel a nuclear reactor can use, a way to reuse byproducts of previous reactions.<br><br>Made by combining Plutonium and Uranium in a Heated Pressure Chamber","Lower maintenance than uranium as fuel, but you've probably got cargo automated at this point?",
    "72*Tiny Piles of Uranium");

function resources1() {
    document.getElementById("resourceTable").innerHTML = `<tb>
                    <tr>
                        <th colspan='2'><img src='images/slimefun/gui/previous_off.png'></th>
                        <th colspan='5'>Resources</th>
                        <th colspan='2'><img src='images/slimefun/gui/next_on.png' onclick='resources2()'></th>
                    </tr>
                    <tr>
                        <td><img src='images/slimefun/resources/ingots/reinforced_alloy.png' title='Reinforced Alloy' onclick='reinforcedAlloy.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/hardened_metal.png' title='Hardened Metal' onclick='hardenedMetal.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/damascus_steel_ingot.png' title='Damascus Steel' onclick='damascusSteel.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/steel_ingot.png' title='Steel' onclick='steel.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/bronze_ingot.png' title='Bronze' onclick='bronze.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/duralumin_ingot.png' title='Duralumin' onclick='duralumin.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/billon_ingot.png' title='Billon' onclick='billon.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/brass_ingot.png' title='Brass' onclick='brass.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/aluminum_brass_ingot.png' title='Aluminum Brass' onclick='aluminumBrass.getInfo()'></td>
                    </tr>
                    <tr>
                        <td><img src='images/slimefun/resources/ingots/aluminum_bronze_ingot.png' title='Aluminum Bronze' onclick='aluminumBronze.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/corinthian_bronze_ingot.png' title='Corinthian Bronze' onclick='corinthianBronze.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/solder_ingot.png' title='Solder' onclick='solder.getInfo()'></td>
                        <td><img src='images/slimefun/resources/valuables/synthetic_sapphire.png' title='Synthetic Sapphire' onclick='syntheticSapphire.getInfo()'></td>
                        <td><img src='images/slimefun/resources/valuables/synthetic_diamond.png' title='Synthetic Diamond' onclick='syntheticDiamond.getInfo()'></td>
                        <td><img src='images/slimefun/resources/valuables/raw_carbon.png' title='Raw Carbonado' onclick='rawCarbonado.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/nickel_ingot.png' title='Nickel' onclick='nickel.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/cobalt_ingot.png' title='Cobalt' onclick='cobalt.getInfo()'></td>
                        <td><img src='images/slimefun/resources/valuables/carbonado.png' title='Carbonado' onclick='carbonado.getInfo()'></td>
                    </tr>
                    <tr>
                        <td><img src='images/slimefun/resources/ingots/ferrosilicon.png' title='Ferrosilicon' onclick='ferrosilicon.getInfo()'></td>
                        <td><img src='images/slimefun/resources/dusts/iron_dust.png' title='Iron Dust' onclick='dusts.getInfo()'></td>
                        <td><img src='images/slimefun/resources/dusts/gold_dust.png' title='Gold Dust' onclick='dusts.getInfo()'></td>
                        <td><img src='images/slimefun/resources/dusts/copper_dust.png' title='Copper Dust' onclick='dusts.getInfo()'></td>
                        <td><img src='images/slimefun/resources/dusts/tin_dust.png' title='Tin Dust' onclick='dusts.getInfo()'></td>
                        <td><img src='images/slimefun/resources/dusts/silver_dust.png' title='Silver Dust' onclick='dusts.getInfo()'></td>
                        <td><img src='images/slimefun/resources/dusts/lead_dust.png' title='Lead Dust' onclick='dusts.getInfo()'></td>
                        <td><img src='images/slimefun/resources/dusts/aluminum_dust.png' title='Aluminum Dust' onclick='dusts.getInfo()'></td>
                        <td><img src='images/slimefun/resources/dusts/zinc_dust.png' title='Zinc Dust' onclick='dusts.getInfo()'></td>
                    </tr>
                    <tr>
                        <td><img src='images/slimefun/resources/dusts/magnesium_dust.png' title='Magnesium Dust' onclick='dusts.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/copper_ingot.png' title='Copper Ingot' onclick='basicIngots.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/tin_ingot.png' title='Tin Ingot' onclick='basicIngots.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/silver_ingot.png' title='Silver Ingot' onclick='basicIngots.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/lead_ingot.png' title='Lead Ingot' onclick='basicIngots.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/aluminum_ingot.png' title='Aluminum Ingot' onclick='basicIngots.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/zinc_ingot.png' title='Zinc Ingot' onclick='basicIngots.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/magnesium_ingot.png' title='Magnesium Ingot' onclick='basicIngots.getInfo()'></td>
                        <td><img src='images/slimefun/resources/valuables/sulfate.png' title='Sulfate' onclick='sulfate.getInfo()'></td>
                    </tr>
                </tb>`
}
function resources2() {
    document.getElementById("resourceTable").innerHTML = `<tb>
                    <tr>
                        <th colspan='2'><img src='images/slimefun/gui/previous_on.png' onclick='resources1()'></th>
                        <th colspan='5'>Resources</th>
                        <th colspan='2'><img src='images/slimefun/gui/next_off.png'></th>
                    </tr>
                    <tr>
                        <td><img src='images/slimefun/resources/valuables/carbon.png' title='Carbon' onclick='carbon.getInfo()'></td>
                        <td><img src='images/slimefun/resources/valuables/compressed_carbon.png' title='Compressed Carbon' onclick='compressedCarbon.getInfo()'></td>
                        <td><img src='images/slimefun/resources/valuables/carbon_chunk.png' title='Carbon Chunk' onclick='carbonChunk.getInfo()'></td>
                        <td><img src='images/slimefun/resources/gold_ingots/gold_ingot_24.png' title='24-Karat Gold' onclick='gold24.getInfo()'></td>
                        <td><img src='images/slimefun/resources/gold_ingots/gold_ingot_22.png' title='22-Karat Gold' onclick='gold22.getInfo()'></td>
                        <td><img src='images/slimefun/resources/gold_ingots/gold_ingot_20.png' title='20-Karat Gold' onclick='gold20.getInfo()'></td>
                        <td><img src='images/slimefun/resources/gold_ingots/gold_ingot_18.png' title='18-Karat Gold' onclick='gold18.getInfo()'></td>
                        <td><img src='images/slimefun/resources/gold_ingots/gold_ingot_16.png' title='16-Karat Gold' onclick='gold16.getInfo()'></td>
                        <td><img src='images/slimefun/resources/gold_ingots/gold_ingot_14.png' title='14-Karat Gold' onclick='gold14.getInfo()'></td>
                    </tr>
                    <tr>
                        <td><img src='images/slimefun/resources/gold_ingots/gold_ingot_12.png' title='12-Karat Gold' onclick='gold12.getInfo()'></td>
                        <td><img src='images/slimefun/resources/gold_ingots/gold_ingot_10.png' title='10-Karat Gold' onclick='gold10.getInfo()'></td>
                        <td><img src='images/slimefun/resources/gold_ingots/gold_ingot_8.png' title='8-Karat Gold' onclick='gold8.getInfo()'></td>
                        <td><img src='images/slimefun/resources/gold_ingots/gold_ingot_6.png' title='6-Karat Gold' onclick='gold6.getInfo()'></td>
                        <td><img src='images/slimefun/resources/gold_ingots/gold_ingot_4.png' title='4-Karat Gold' onclick='gold4.getInfo()'></td>
                        <td><img src='images/slimefun/resources/valuables/silicon.png' title='Silicon' onclick='silicon.getInfo()'></td>
                        <td><img src='images/slimefun/resources/ingots/gilded_iron.png' title='Gilded Iron' onclick='gildedIron.getInfo()'></td>
                        <td><img src='images/slimefun/resources/valuables/synthetic_emerald.png' title='Synthetic Emerald' onclick='syntheticEmerald.getInfo()'></td>
                        <td><img src='images/slimefun/resources/radioactive_materials/uranium.png' title='Uranium' onclick='uranium.getInfo()'></td>
                    </tr>
                    <tr>
                        <td><img src='images/slimefun/resources/ingots/redstone_alloy_ingot.png' title='Redstone Alloy' onclick='redstoneAlloy.getInfo()'></td>
                        <td><img src='images/slimefun/resources/valuables/magnesium_salt.png' title='Magnesium Salt' onclick='magnesiumSalt.getInfo()'></td>
                        <td><img src='images/slimefun/resources/fuel/oil.png' title='Bucket of Oil' onclick='oil.getInfo()'></td>
                        <td><img src='images/slimefun/resources/fuel/fuel.png' title='Bucket of Fuel' onclick='fuel.getInfo()'></td>
                        <td><img src='images/slimefun/resources/valuables/nether_ice.png' title='Nether Ice' onclick='netherIce.getInfo()'></td>
                        <td><img src='images/slimefun/resources/radioactive_materials/blistering_ingot_33.png' title='Blistering Ingot (33%)' onclick='blisteringIngot33.getInfo()'></td>
                        <td><img src='images/slimefun/resources/radioactive_materials/blistering_ingot_66.png' title='Blistering Ingot (66%)' onclick='blisteringIngot66.getInfo()'></td>
                        <td><img src='images/slimefun/resources/radioactive_materials/blistering_ingot_100.png' title='Blistering Ingot (100%)' onclick='blisteringIngot100.getInfo()'></td>
                        <td><img src='images/slimefun/resources/valuables/enriched_nether_ice.png' title='Enriched Nether Ice' onclick='enrichedNetherIce.getInfo()'></td>
                    </tr>
                    <tr>
                        <td><img src='images/slimefun/resources/radioactive_materials/neptunium.png' title='Neptunium' onclick='neptunium.getInfo()'></td>
                        <td><img src='images/slimefun/resources/radioactive_materials/plutonium.png' title='Plutonium' onclick='plutonium.getInfo()'></td>
                        <td><img src='images/slimefun/resources/radioactive_materials/boosted_uranium.png' title='Boosted Uranium' onclick='boostedUranium.getInfo()'></td>
                    </tr>
                </tb>`;
}